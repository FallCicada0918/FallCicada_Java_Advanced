package com.briup.demo.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * @program: demo
 * @description: 图书映射接口
 * @author: rendc
 * @create: 2024-11-28 15:08
 **/
@Mapper
public interface BookMapper {
}
